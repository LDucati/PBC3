INPUT			PURPOSE								OUTPUT(S)
mappers.xyz             sets element mappers and prints solute and 2 neighbors		mappers_geompar.xyz  mappers_neighbor.xyz mappers_trajectory.xyz
			and trajectory file

mappers-2.xyz           same as above but with different values. prints solute 		mappers-2_geompar.xyz  mappers-2_neighbor.xyz
			and 2 neighbors and trajectory file

a-mapper.xyz		modifies atom mapper and prevails over elemment mapper		a-mapper_geompar.xyz  a-mapper_neighbor.xyz a_mapper_trajectory.xyz	

bond.xyz		prints selected bond distances					bond_geompar.xyz

bond.xyz		prints all bond distances					bonds_geompar.xyz

angle.xyz		prints selected angles						angle_geompar.xyz

angles.xyz		prints all angles						angles_geompar.xyz

dihedral.xyz		prints selected dihedral angles					dihedral_geompar.xyz

dihedrals.xyz		prints all dihedral angles					dihedrals_geompar.xyz

molecule.xyz		prints all molecules found					molecule_geompar.xyz

molecule-2.xyz		prints only molecule #10 found					molecule-2_geompar.xyz

neighbors.xyz		prints the solute and all nearsted neighbor molecules found	neighbors_neighbor.xyz

neighbors_10.xyz	prints the solute and 10 nearest neighbor molecules found	neighbors_10_neighbor.xyz

cell.xyz		genetares the supercell and prints it in two formats		cell_supercell.xyz cell_supercell.axsf

H-topology.xyz		searches for hydrogens with more than one bond			H-topology_*_trajectory.xyz  H-topology_trajectory.xyz
			and keeps only the shortest contact

incell.xyz		puts atoms outside of the cubc boz inside the box		incell_geompar.xyz

incellcmass.xyz		puts the molecules outside the cubic box inside the box		incellcmass_geompar.xyz
			based on the center of mass for selection

origin_atom.xyz		Puts the atom number 3 in the origin of cartesian		origin_atom_geompar.xyz

origin_atom_coords.xyz	Puts the atom number 3 in the pecified cartesian coordinates	origin_atom_coords_geompar.xyz

solute.xyz		sets the molecule number # 2 as solute and prints it		solute_geompar.xyz solute_solute.xyz
			in separate file

trajectory.xyz		print the number of nearest neighbor requested in trajectory	trajectory_trajectory.xyz
			style file. selection of NNS will be based on solute molecule

trajectory-atom.xyz	print the number of nearest neighbor requested in trajectory	trajectory-atom_trajectory.xyz
			style file. the selection of NNS will be based on atom

trajectory-step5.xyz	print the number of nearest neighbor requested in trajectory	trajectory-step5.xyz trajectory-step5_trajectory.xyz trajectory-step5_*_trajectory.xyz
			style file. also print the solute and nearest solvent in steps
			of five in separate files

trajectory-incell.xyz   same as trajectory.xyz input but first puts all atoms inside 	trajectory-incell_trajectory.xyz trajectory-incell_geompar.xyz
			the cubic cell before creates the supercell and make a
			selection of the nearest neighbor solvents of solute

trajectory-incell-2.xyz	same as the above but this example is crucial to put all the	trajectory-incell-2_trajectory.xyz trajectory-incell-2_*_trajectory.xyz trajectory-incell-2_geompar.xyz
			atoms inside the box in order to center the solute molecule	trajectory-incell-2_supercell.*
			in the cubic box. also prints the solute and NNS in steps and
			the supercell.




